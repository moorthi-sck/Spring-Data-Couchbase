package com.javatechie.couchbase.api;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.couchbase.repository.config.EnableCouchbaseRepositories;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.javatechie.couchbase.api.model.Customer;
import com.javatechie.couchbase.api.repository.CustomerRepository;
//@EntityScan("com.javatechie.couchbase.api.model")
//@EnableCouchbaseRepositories("com.javatechie.couchbase.api.repository")
@SpringBootApplication
@RestController
public class SpringDataCouchbaseApplication {
	
	private final Logger LOG = LoggerFactory.getLogger(getClass());

	@Autowired
	private CustomerRepository repository;


	@RequestMapping(value = "/create", method = RequestMethod.POST)
	public Customer addNewUsers(@RequestBody Customer customer) {
		
		return repository.save(customer);
	}
	
 	@GetMapping("/getCustomer/{id}")
	public Optional<Customer> getOptional(@PathVariable int id) {
		return repository.findById(id);
	}

	@GetMapping("/fetchAllCustomers")
	public Iterable<Customer> getAll() {
		return repository.findAll();
	}
	
	@RequestMapping(value = "/getAllCustomers", method = RequestMethod.GET)
	public List<Customer> getAllCustomers() {
		LOG.info("Getting all users.");
		return (List<Customer>) repository.findAll();
	}
	
	@DeleteMapping("delete/{id}")
	public ResponseEntity<Customer> deleteCustomer(@PathVariable("id") Integer id) {
		repository.deleteById(id);
		return new ResponseEntity<Customer>(HttpStatus.NO_CONTENT);
	}	

	public static void main(String[] args) {
		SpringApplication.run(SpringDataCouchbaseApplication.class, args);
	}

}
