package com.javatechie.couchbase.api.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.couchbase.core.query.N1qlPrimaryIndexed;
import org.springframework.data.couchbase.core.query.Query;
import org.springframework.data.couchbase.core.query.ViewIndexed;
import org.springframework.data.couchbase.repository.CouchbaseRepository;

import com.javatechie.couchbase.api.model.Customer;
@N1qlPrimaryIndexed
@ViewIndexed(designDoc="customer",viewName="all")
public interface CustomerRepository extends CouchbaseRepository<Customer, Integer>{


//	@Query("#{#n1ql.selectEntity} where #{#n1ql.filter} AND ANY id IN JavaTechie SATISFIES id = $1 END")
////	List<Customer> getOptional(int id);
//	  @Query("#{#n1ql.selectEntity} WHERE roles = 'Full Admin' AND #{#n1ql.filter}")
//	    Iterable<Customer> getAll();

}