//package com.javatechie.couchbase.api.controller;
//
//import java.util.stream.Collectors;
//import java.util.stream.Stream;
//
//import javax.annotation.PostConstruct;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.autoconfigure.couchbase.CouchbaseProperties.Endpoints.CouchbaseService;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.couchbase.client.core.service.Service;
//import com.javatechie.couchbase.api.model.Customer;
//import com.javatechie.couchbase.api.repository.CustomerRepository;
//import com.javatechie.couchbase.api.service.CustomerService;
//
//
//@RestController
//
//public class CustomerController {
//	@Autowired
//	private CustomerRepository repository;
//
//	@PostConstruct public void initCustomerRepo() { repository.saveAll(Stream
//			.of(new Customer(111, "John", new String[] { "Bangalore", "Marathali" }), new
//					Customer(222, "Pitter", new String[] { "Hyderabad", "SR Nagar" }))
//			.collect(Collectors.toList())); }
//	//	 
//	//	@PostMapping("/customer")
//	//	public void create(@RequestBody Customer customer) {
//	//		 CustomerService.create(customer);		
//	//	}
//
//	@GetMapping("/fetchAllCustomers")
//	public Iterable<Customer> getAll() {
//		return repository.findAll();
//	}
//
//}
