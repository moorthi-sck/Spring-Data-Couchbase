//package com.javatechie.couchbase.api.service;
//
//import org.springframework.stereotype.Service;
//
//import com.javatechie.couchbase.api.model.Customer;
//@Service
//public class CustomerService {
//
//	public static void create(Customer customer) {
//		// TODO Auto-generated method stub
//		
//	}
//
//}
