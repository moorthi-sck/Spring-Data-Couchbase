package com.javatechie.Spring.Data.Couchbase;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDataCouchbaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
